function batch_straightening_stacksMany4(id_rfp, id_gfp, id_dapi, indatadir, outdatadir, prefix, idx, xy_rez, z_rez, zoom_f,startLoc)
% function batch_straightening_stacks4(id_rfp, id_gfp, id_dapi, indatadir,outdatadir, prefix, idx, xy_rez, z_rez, zoom_f)
%
% batch file for straighten worm image stacks
%
% F.Long



if (startLoc <5)
    stanford = 01
    straightOne = 01
    
    %    if straightOne
    if ((startLoc < 2) )
        for i=1:length(idx)
            k = idx(i)
            idx
            if ((startLoc < 1))
                
                %if ~(exist([outdatadir{k}, 'xydim.mat'],'file')) % we need to start froms cratch
                
                outdatadir{k}
                if (exist([outdatadir{k}, 'crop_straight_blue_xyz.raw'],'file')) % can also use stanford;
                    'reading it in single'
                    [outdatadir{k}, 'crop_straight_blue_xyz.raw']
                    a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_blue_xyz.raw']));
                    'obtained'
                    
                elseif ~(exist([outdatadir{k}, 'crop_straight_xyz.raw'],'file')) % can also use stanford;
                    a = uint8(readStanfordEleganStack_FL2Many([indatadir{k}], prefix{k}, id_dapi, xy_rez, z_rez, zoom_f,0));
                    size(a)
                    if size(a,1) == 0
                        'file not found'
                        a = uint8(readStanfordEleganStack_FL2_singleChan([indatadir{k}], prefix{k}, id_dapi, xy_rez, z_rez, zoom_f,id_gfp));
                        saveStack2Raw(uint8(a), [outdatadir{k}, 'crop_straight_green_xyz.raw']);
                        if(min(size(a))==size(a,1))
                            dipshow(max(a));
                            elif(min(size(a))==size(a,2))
                            dipshow(max(permute(a, [2 1 3])));
                        else
                            dipshow(max(permute(a, [3 1 2])));
                        end;
                        clear a;
                        a = uint8(readStanfordEleganStack_FL2_singleChan([indatadir{k}], prefix{k}, id_dapi, xy_rez, z_rez, zoom_f,id_rfp));
                        saveStack2Raw(uint8(a), [outdatadir{k}, 'crop_straight_red_xyz.raw']);
                        clear a;
                        a = uint8(readStanfordEleganStack_FL2_singleChan([indatadir{k}], prefix{k}, id_dapi, xy_rez, z_rez, zoom_f,id_dapi));
                        saveStack2Raw(uint8(a), [outdatadir{k}, 'crop_straight_blue_xyz.raw']);
                    else
                        saveStack2Raw(uint8(a), [outdatadir{k}, 'crop_straight_xyz.raw']);
                        a = a(:,:,:,id_dapi);
                    end;
                    %20100902 we only send the dapi channel in
                else
                    [outdatadir{k}, 'crop_straight_xyz.raw']
                    a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_xyz.raw']));
                    size(a)
                    if size(a,1) == 0
                        a = uint8(readStanfordEleganStack_FL2Many([indatadir{k}], prefix{k}, id_dapi, xy_rez, z_rez, zoom_f,0));
                    else
                        'reading it in'
                        [outdatadir{k}, 'crop_straight_xyz.raw']
                        a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_xyz.raw']));
                        'obtained'
                    end;
                    %20100902 we only send the dapi channel in
                    a = a(:,:,:,id_dapi);
                end;
                
                nd = ndims(a);
                if (nd>=4),
                    bb = max(squeeze(a(:,:,:,id_dapi)),[],3);
                else,
                    bb = max(squeeze(a),[],3);
                end;
                save([outdatadir{k},'xymax.mat'],'bb');
                clear bb;
                [outdatadir{k},'xy']
                
                'straight now'
                main_straightenWorm2_step1(a,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xy']);
                clear a;
                close all;
            end;
        end;
        
        %now allow for manual correction
        if ((startLoc < 1.5))
            i = 1
            while i<=length(idx)
                k = idx(i)
                locprefix = [outdatadir{k},'xy']
                RRgood = main_straightenWorm2_step2(id_gfp,id_dapi, zoom_f,[outdatadir{k},'xy']);
                if RRgood==1,
                    i = i+1
                end;
                %            clear bb;
                %            clear c;
                %            clear bpos;
                close all;
            end;
            
        end;
        %finally we save the stacks based on how they are processed
        for i=1:length(idx)
            k = idx(i)
            %do it in 3 steps for saving memory
            if (exist([outdatadir{k}, 'crop_straight_blue_xyz.raw'],'file')) % can also use stanford;
                'straighten single'
                a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_blue_xyz.raw']));
                t=main_straightenWorm2_step3L1(a,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xy']);
                size(t)
                a1(:,:,:,id_dapi) = squeeze(t);
                size(a1)
                clear t;
                clear a;
                a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_green_xyz.raw']));
                a1(:,:,:,id_gfp)=main_straightenWorm2_step3L1(a,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xy']);
                clear a;
                a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_red_xyz.raw']));
                a1(:,:,:,id_rfp)=main_straightenWorm2_step3L1(a,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xy']);
                clear a;
                writeim(uint8(a1), [outdatadir{k},'crop_straight_xy.ics'],'ics');
                c = permute(uint8(a1), [3 2 1 4]);
                clear a1;
            else
                a=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_xyz.raw']));
                b=main_straightenWorm2_step3L1(a,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xy']);
                writeim(uint8(b), [outdatadir{k},'crop_straight_xy.ics'],'ics');
                clear a;
                c = permute(uint8(b), [3 2 1 4]);
                clear b;
            end;
            saveStack2Raw(c, [outdatadir{k},'crop_straight_xy.raw']);
            clear c;
            close all;
        end;
    end;
    
    %correct color shift
    if (startLoc < 3)
        for i=1:length(idx)
            k = idx(i)
            outdatadir{k}
            [s, dis] = rfpShiftCorrection([outdatadir{k},'crop_straight_xy.ics'], id_rfp, id_dapi);
            writeim(uint8(s), [outdatadir{k},'crop_straight_xy.ics'],'ics');
            [s, dis] = rfpShiftCorrection([outdatadir{k},'crop_straight_xy.ics'], id_gfp, id_dapi);
            writeim(uint8(s), [outdatadir{k},'crop_straight_xy.ics'],'ics');
            c = permute(uint8(s), [3 2 1 4]);
            saveStack2Raw(c, [outdatadir{k},'crop_straight_xy.raw']);
             dipshow(s)
            clear c
	    clear s

        end;
    end;
    
    
    if (startLoc < 5)
        for i=1:length(idx)
            k = idx(i)
            outdatadir{k}
            if ((startLoc < 4))
                if ~(exist([outdatadir{k}, 'xzdim.mat'],'file')) % can also use stanford;
                    
                    [outdatadir{k},'crop_straight_xy.raw']
                    
                    c=uint8(loadRaw2Stack([outdatadir{k},'crop_straight_xy.raw']));
                    
                    %20100902 we only send the dapi channel in
                    c = c(:,:,:,id_dapi);
                    
                    nd = ndims(c);
                    if (nd>=4),
                        bb = max(squeeze(c(:,:,:,id_dapi)),[],3);
                    else,
                        bb = max(squeeze(c),[],3);
                    end;
                    save([outdatadir{k},'xzmax.mat'],'bb');
                    
                    main_straightenWorm2_step1(c,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xz']);
                    close all;
                    clear c;
                end;
            end;
        end;
        %now allow for manual correction
        
        i = 1
        while i<=length(idx)
            k = idx(i)
            
            locprefix = [outdatadir{k},'xz']
            RRgood=main_straightenWorm2_step2(id_gfp,id_dapi, zoom_f,[outdatadir{k},'xz']);
            if RRgood==1,
                i = i+1
            end;
            close all;
            
        end;
        
    end;
    %finally we save the stacks based on how they are processed
    for i=1:length(idx)
        k = idx(i)
        
        [outdatadir{k}, 'crop_straight_xy.raw']
        c=uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight_xy.raw']));
        d = main_straightenWorm2_step3L1(c,id_gfp,id_dapi, zoom_f,[outdatadir{k},'xz']);
        clear c;
        e = permute(uint8(d), [3 2 1 4]);
        clear d;
        e = e(end:-1:1,:,:,:);
        e = e(:,end:-1:1,end:-1:1,:);
        f = main_flipWorm(e, id_gfp, id_dapi);
        clear e;
        f1 = permute(uint8(f), [2 1 3 4]);
        clear f;
        saveStack2Raw(f1, [outdatadir{k}, 'crop_straight.raw']);
        clear f1;
        close all;
    end;
    %finally we trim the stacks based on how they are processed
end;

if 1
    for i=1:length(idx)
        
        'cropping'
        
        k = idx(i)
        [outdatadir{k}, 'crop_straight.raw']
        exist([outdatadir{k}, 'crop_straight_pre_GFP.raw'],'file')
        if  strcmp(input('Need to check for trim? (y/n) ','s'),'y')==1
            [outdatadir{k}, 'crop_straight_pre_GFP.raw']
            f1 = uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight.raw']));
            whos f1
            tf1 = squeeze(max(f1(:,:,:,end)));
            dipshow(max(permute(squeeze(f1(:,:,:,end)),[2 1 3])));
            dipshow(max(permute(squeeze(f1(:,:,:,end)),[3 1 2])));
            dipshow(tf1)
            cb = manual_select_bndbox_XY(tf1);
            dipshow(max((f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:))));
            f2 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
            whos f2
            clear f2;
            while strcmp(input('good trim? (y/n) ','s'),'y')~=1
                close all;
                whos f1
                cb = manual_select_bndbox_XY(tf1);
                dipshow(max((f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:))));
                f2 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
                whos f2
                clear f2;
            end;
            
            size(f1)
            f1 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
            size(f1)
            whos f1
            saveStack2Raw(f1, [outdatadir{k}, 'crop_straight.raw']);
            
            
            %writeim(f1, [outdatadir{k}, 'crop_straight.ics'], 'ics');
            
            close all;
            clear f1;
            clear tf1;
            if (startLoc ==5.5)
                if (exist([outdatadir{k}, 'crop_straight_pre_DAPI.raw'],'file')) % can also use stanford;
                    'yes blue'
                    f1 = loadRaw2StacK([outdatadir{k}, 'crop_straight_pre_DAPI.raw']);
                    size(f1)
                    f1 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
                    size(f1)
                    clear f1
                end;
                if (exist([outdatadir{k}, 'crop_straight_pre_GFP.raw'],'file')) % can also use stanford;
                    'yes green'
                    f1 = loadRaw2StacK([outdatadir{k}, 'crop_straight_pre_GFP.raw']);
                    size(f1)
                    f1 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
                    size(f1)
                    clear f1
                end;
                if (exist([outdatadir{k}, 'crop_straight_pre_RFP.raw'],'file')) % can also use stanford;
                    'yes red'
                    f1 = loadRaw2StacK([outdatadir{k}, 'crop_straight_pre_RFP.raw']);
                    size(f1)
                    f1 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
                    size(f1)
                    clear f1
                end;
            end;
            clear cb;
        end;
    end;
end;

for i=1:length(idx)
    
    k = idx(i)
    [outdatadir{k}, 'crop_straight.raw']
    f1 = uint8(loadRaw2Stack([outdatadir{k}, 'crop_straight.raw']));
    whos f1
    if  strcmp(input('Need to check for trim? (y/n) ','s'),'y')==1
        d = f1(:,:,:,end);
        dipshow(max(d));
        dipshow(max(permute(d,[2 1 3])));
        dipshow(max(permute(d,[3 1 2])));
        if  strcmp(input('Need trim? (y/n) ','s'),'y')==1
            startNum  = 1
            endNum = size(f1,1)
            startNum = str2num(input('start location: ','s'))
            if startNum == 0
                startNum = 1
            end;
            endNum = str2num(input('end location: ','s'))
            if endNum == 0
                endNum = size(f1,1)
            end;
            dipshow(max(permute(d(startNum:endNum,:,:),[3 1 2])));
            f2 = f1(startNum:endNum,:,:,:);
            whos f2
            clear f2;
            
            while strcmp(input('good trim? (y/n) ','s'),'y')~=1
                whos f1
                startNum = str2num(input('start location: ','s'))
                if startNum == 0
                    startNum = 1
                end;
                endNum = str2num(input('end location: ','s'))
                if endNum == 0
                    endNum = size(f1,1)
                end;
                size(f1(startNum:endNum,:,:))
                dipshow(max(permute(d(startNum:endNum,:,:),[3 1 2])));
                f2 = f1(startNum:endNum,:,:,:);
                whos f2
                clear f2;
            end;
            saveStack2Raw(f1(startNum:endNum,:,:,:), [outdatadir{k}, 'crop_straight.raw']);
            if (startLoc ==5.5)
                if (exist([outdatadir{k}, 'crop_straight_pre_DAPI.raw'],'file')) % can also use stanford;
                    'yes blue'
                    f1 = loadRaw2StacK([outdatadir{k}, 'crop_straight_pre_DAPI.raw']);
                    size(f1)
                    f1 = (f1(startNum:endNum,:,:));
                    size(f1)
                    clear f1
                end;
                if (exist([outdatadir{k}, 'crop_straight_pre_GFP.raw'],'file')) % can also use stanford;
                    'yes green'
                    f1 = loadRaw2StacK([outdatadir{k}, 'crop_straight_pre_GFP.raw']);
                    size(f1)
                    f1 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
                    size(f1)
                    clear f1
                end;
                if (exist([outdatadir{k}, 'crop_straight_pre_RFP.raw'],'file')) % can also use stanford;
                    'yes red'
                    f1 = loadRaw2StacK([outdatadir{k}, 'crop_straight_pre_RFP.raw']);
                    size(f1)
                    f1 = (f1(:,cb.min_xx:cb.max_xx,cb.min_yy:cb.max_yy,:));
                    size(f1)
                    clear f1
                end;
            end;
        end;
        clear d;
    end;
    clear f1;
    close all;
end;
