function out_ept = smooth_object_contour(ept, rx, ry, method)
%function out_ept = smooth_object_contour(ept, rx, ry, method)
%
% Smooth the contour of an object specified by the edge point structure ept
% 
%
% rx,  ry: the smoothing kernel sizes. If only specified one, then the other one is set to be the same. If not specified, the default is 10 pixels
% method: 'Gauss', 'median', or 'Mean', default is "Gauss"
%
% Copyright Hanchuan Peng
% 20051129

if nargin<4,
    method = 'Gauss';
end;

if nargin<2,
    rx = 10;
    ry = rx;
end;

if nargin<3,
    ry = rx;
end;

if rx<1 | ry<1,
    error('The Gaussian smoothing kernels must have sizes bigger than 1 (1 is no smoothing)!!!');
end;


xx = ept.x(:)
yy = ept.y(:)

xx = [xx(end-2*rx+1:end) ; xx ;xx(1:2*rx)];
yy = [yy(end-2*ry+1:end) ; yy ; yy(1:2*ry)];

switch upper(method)
case 'GAUSS',
        
	xx = double(gaussf(xx,rx));
	yy = double(gaussf(yy,ry));

case 'MEDIAN',

    xx = double(medif(xx,rx));
	yy = double(medif(yy,ry));

case 'MEAN',
    
	xx = double(convolve(xx,repmat(1/rx, 1, rx)));
	yy = double(convolve(yy,repmat(1/ry, 1, ry)));

otherwise,
    
    error('Unsupport method!');
    
end;

out_ept.x = xx(2*rx+1:end-2*rx); out_ept.x=out_ept.x(:)';
out_ept.y = yy(2*ry+1:end-2*ry); out_ept.y=out_ept.y(:)';

figure;
hold on;
h_in = plot(ept.y(:), ept.x(:));
h_out = plot(out_ept.y(:), out_ept.x(:));
set(h_in, 'Color', [0 0 1]);
set(h_out, 'Color', [1 0 0]);
axis image;

return;
