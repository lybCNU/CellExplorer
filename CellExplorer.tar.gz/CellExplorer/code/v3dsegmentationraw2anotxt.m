function v3dsegmentationraw2anotxt(maskraw,inimgraw,anotxt)
%%regenerate srs.apo made by QU LEI' software
%%this function will generate "*_srs.ano", "*_srs.ano.ano.txt", "*_fixcell_input.ano", "*_fixcell_input.mask.raw",
%%"*_fixcell_input.ano.ano.txt", "*_fixcell_output.ano"
%%
%%20150906
%%LI YONG BIN
%%

%%%%run srs
%srs_comm=['wine /home/xiaoliu/demo4LiuXiao_150824/bin/main_allcellseganno_uint16.exe -t ',num2str(stack),'/',num2str(stack),'_S1_crop_straight.raw -a /home/xiaoliu/demo4LiuXiao_150824/data/b_atlas_reformat.apo -i /home/xiaoliu/demo4LiuXiao_150824/data/mylist.txt -o ', num2str(stack),'/',num2str(stack),'_S1_srs.apo -s ', num2str(stack),'/',num2str(stack),'_S1_srs.ano.mask.raw -c 3 -f 1 -d 4 -m 1 -T 20'];
%unix(srs_comm);

%%%%generate"*_srs.ano", "*_srs.ano.ano.txt"
%stack;
maskraw
inimgname=num2str(inimgraw);
segfilename=num2str(maskraw);
inimg = uint8(loadRaw2Stack(inimgname));
segres = uint16(loadRaw2Stack(segfilename));
inimgsize=size(inimg(:,:,:,3));
%fixmask=uint16(zeros(inimgsize(1),inimgsize(2),inimgsize(3)));
%fixmaskfile=[stack,'/',stack,'_S1_fixcell_input.ano.mask.raw'];
%saveStack2Raw(fixmask,fixmaskfile)
inimg_channel = dip_image(squeeze(inimg(:,:,:,3))); %channel_id=3,dapi
outimg_label = dip_image(segres);

%[a,b,cellname]=textread('/home/xiaoliu/code/mcode/b_atlas.name','%s %s %s','delimiter',',','headerlines',1);

img_gray=inimg_channel;
img_objMask=outimg_label;


%if stack(end)~='/',
%    targetdir = [stack '/'];
%end;
%if ~exist(targetdir, 'dir'), %%051008
%    mkdir(targetdir);
%end;

size(img_gray)
size(img_objMask)

r = struct(measure(img_objMask,  img_objMask, {'center', 'gravity', 'Mean', 'Stddev', 'Size', 'maxval'}))

dimensions = size(img_gray);
NDepth = size(img_gray,3);
tempNeigh = uint16(img_objMask);

ridx = regionprops(uint16(img_objMask),'PixelIdxList');
for j=1:length(r), 
    ids =r(j).id
    %i = r(j).id
    i=j
    length(r)
	size(ridx(i).PixelIdxList)
  [x y z ] = ind2sub(dimensions,ridx(i).PixelIdxList);
  [coeff scores latent] = pca([x y z]);
    neighbors=zeros(6,1);
    c_n = 1;

        t(i,:)=[r(i).Gravity(1)... %1
	   r(i).Gravity(2)...
	   r(i).Gravity(3)... %3
	   r(i).id...
	   r(i).Mean... %5
	   r(i).StdDev... 
	   r(i).Size... %7
	   r(i).MaxVal... %8
	  ];
r(i).id
    t(i,1:3) = round(t(i,1:3));

end;
clear tempNeigh;
%%========== merge local maxima ==

%%t = mergeLocalMax(t);
%t = t';

%%%========== sort the cell using the x coordinates (from left to right)

NCOL = size(t,2)+1;

[tmp, II] = sort(t(:,4));
for i=1:size(t,1),
    t(i,NCOL) = find(II==i); % find the sorted index number
end;



fid = fopen([anotxt], 'wt');
RR = 5;
siz = size(img_gray);
'size t'
size(t,1)
'size img_gray'
siz
for i=1:size(t,1),

    j = II(i);

    mean_tmpv = t(j, 5);
    peak_tmpv =     t(j, 8);
    fprintf(fid, '%d,%d,,,%d,%d,%d,%5.2f,%5.2f,%5.2f,%d,%d\n', ...        
        t(j,4), j,t(j,3), t(j,2), t(j,1), peak_tmpv, mean_tmpv, t(j,6), t(j,7), round(t(j,7)*mean_tmpv)); % generate csv file, Apr.30, 2006    
end;
%    fid1 = fopen([maskraw,'.ano'],'wt');
%    fprintf(fid1, 'GRAYIMG=%s\n',inimgraw);
%    fprintf(fid1, 'MASKIMG=%s\n', maskraw);
%    fprintf(fid1, 'ANOFILE=%s\n', [maskraw,'.ano.ano.txt']);
    
%    fid2 = fopen([num2str(stack),'/',num2str(stack),'_S1_fixcell_input.ano'],'wt');
%    fprintf(fid2, 'GRAYIMG=%s\n',[num2str(stack),'_S1_crop_straight.raw']);
%    fprintf(fid2, 'MASKIMG=%s\n', [num2str(stack),'_S1_fixcell_input.ano.mask.raw']);
%    fprintf(fid2, 'ANOFILE=%s\n', [num2str(stack),'_S1_fixcell_input.ano.ano.txt']);
    
%    fid3 = fopen([num2str(stack),'/',num2str(stack),'_S1_fixcell_input.ano.ano.txt'],'wt');
%    fprintf(fid3, '\n');
    
    
fclose(fid);
%fclose(fid1);
%fclose(fid2);
%fclose(fid3);
clc;
clear all;

