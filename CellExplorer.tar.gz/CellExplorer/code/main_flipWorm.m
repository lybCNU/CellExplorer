function outimg = main_flipWorm(inimg, id_gfp, id_dapi)
% function outimg = main_flipWorm(inimg, id_gfp, id_dapi)
%
% flip image stacks so that: 
% head is left, tail right
%
% Copyright Fuhui Long
% 20060523


xsize = size(inimg,2);
ysize = size(inimg,1);
zsize = size(inimg,3);
channelSize = size(inimg,4);

proj1d = sum(sum(inimg(:,:,:,id_dapi),1),3); 
[maxVal, maxIdx] = max(proj1d);
if (maxIdx > xsize/2) 
    outimg = inimg(end:-1:1, end:-1:1, :, :);
else
    outimg = inimg;
end;


