function batch_preprocessing_stacksdapi2(psfSize, idx, datadir, channelNo, channel_id, deconvolutionTag)
% function batch_preprocessing_stacks2(psfSize, idx, datadir, channelNo, channel_id, deconvolutionTag)
% 
% batch file for preprocessing of worm stacks for segmentation 
% Copyright F. Long
% 20060530
% 20061216

if channelNo < 3
    id_gfp = channel_id(1);
    id_dapi = channel_id(2);
else
    id_rfp = channel_id(1);
    id_gfp = channel_id(2);
    id_dapi = channel_id(3);
end;

for k=1:length(idx)

    i = idx(k);
    outToStcreen='HERE_NOW'
    imgname = [datadir{i}, '_crop_straight.raw']; 


outimgnamedevDAPI =''; 
outimgnamedevGFP =''; 
outimgnamedevRFP ='';         

outimgnamepreDAPI = [datadir{i}, '_crop_straight_pre_DAPI.ics'];
outimgnamepreGFP = [datadir{i}, '_crop_straight_pre_GFP.ics'];
outimgnamepreRFP = [datadir{i}, '_crop_straight_pre_RFP.ics'];

segNucleiPreDAPI(imgname, outimgnamedevDAPI, outimgnamepreDAPI, id_dapi,  psfSize);
%segNucleiPreDAPI(imgname, outimgnamedevGFP, outimgnamepreGFP, id_gfp,  psfSize);
%segNucleiPreDAPI(imgname, outimgnamedevRFP, outimgnamepreRFP, id_rfp,  psfSize);
    
end;
outToStcreen = 'done'
