function bbox = manual_select_bndbox_XY(inimg)
%function bbox = manual_select_bndbox(inimg)
% 
% Manually define the bounding box of an image
%
% Copyright Hanchuan Peng
% 20051002

cimg = inimg;
sz = size(cimg);

[maskimg, CY, CX] = roipoly(cimg);
CX = round(CX);
CY = round(CY);

imagesc(maskimg); axis image;

min_xx = min(CX);
max_xx = max(CX);
min_yy = min(CY);
max_yy = max(CY);

marginb = 5;

bbox.min_xx = max(1, min_xx-marginb);
bbox.max_xx = min(size(maskimg,1), max_xx+marginb);
bbox.min_yy = max(1, min_yy-marginb);
bbox.max_yy = min(size(maskimg,2), max_yy+marginb);

