function segNucleiPre(imgname, outimgnamedev, outimgnamepre, channelID,  psfSize)
% function segNucleiPre(imgname, outimgnamedev, outimgnamepre, channelID,  psfSize)

% preprocessing of image stacks, including deconvolution, gaussian
% smoothing, and non-uniform background removing
% 
% Copyright: F. Long
% 20060410

  IDname = {'RFP', 'GFP', 'DAPI'};
colorname = {'red', 'green', 'blue'};

D = dir(imgname);
if 1
%if it is simply too large to segment at all
if (D.bytes > 2.5*power(10,9))
    %this is too large to segment and needs trimming first
       return;
end;
imgname
img = uint8(loadRaw2Stack(imgname)); % read original image
img_ori = squeeze(img(:,:,:,channelID)); 
size(img_ori)
% deconvolve image
if (~isempty(outimgnamedev))
    resimg1 = deconvolve(imgname, outimgnamedev, channelID, psfSize);
else
    resimg1 = img_ori;
end;


% gaussian smoothing

inimg =  uint8(gaussf(resimg1,1)); 

% non-uniform background removing
inimg = unifybgn(inimg);


writeim(inimg,outimgnamepre,'ics');
saveStack2Raw(uint8(inimg),[outimgnamepre(1:length(outimgnamepre)-3) 'raw']);

locs = find(outimgnamepre=='/');

types={'RFP', 'GFP', 'DAPI'}
type = types{channelID}
Y = permute(uint8(inimg), [2, 1, 3]); % unit8 will permute
if 0
for i=1:size(Y, 3)
  Z = Y(:,:,i);
preImgStr = [outimgnamepre(1:locs(end)) type '/imgSlices/image']
  leading0 = '00';
  if (floor(i/10)>0)
    leading0='0';
  end;
  if (floor(i/100)>0)
    leading0='';
  end;

  numImgStr = num2str(i);
  postImgStr = '.tif';
  imgStr = [preImgStr, leading0, numImgStr, postImgStr]
  imwrite(Z, imgStr, 'tif');
end
end;
end;
outimgnamepre

inimg = readim(outimgnamepre);
sz = size(inimg)
%if we need to split this into multiple segments for segmentation 
if (D.bytes > .85*power(10,9))
    numSegs = 5
    starts = []
    ends = []
    [starts ends] = computeDividingRegions(sz,numSegs);
    nam = strcat(outimgnamepre(1:find(outimgnamepre=='/',1,'last')), 'DAPI/imgSlices/image_analyze_', colorname{channelID})
    saveStack2AnalyzeLong_c(uint8(inimg),nam);
    for seg=1:length(starts)
	starti = starts(seg)
	endi = ends(seg)
	nam = strcat(outimgnamepre(1:find(outimgnamepre=='/',1,'last')), 'DAPI/imgSlices/image_analyze-',num2str(seg-1),'_', colorname{channelID})

	subinimg = inimg(:,starti:endi,:);
        size(subinimg);
        saveStack2AnalyzeLong_c(uint8(subinimg),nam);

check = analyze75info([nam '.hdr']);
  check = analyze75read(check);
     end;

else
nam = strcat(outimgnamepre(1:find(outimgnamepre=='/',1,'last')), 'DAPI/imgSlices/image_analyze_', colorname{channelID})
saveStack2AnalyzeLong_c(uint8(inimg),nam);

end;

