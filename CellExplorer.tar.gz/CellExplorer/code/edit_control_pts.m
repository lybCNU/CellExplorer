function bposnew = edit_control_pts(bb, bpos)
%function bposnew = edit_control_pts(inimg, bpos)
% A simple interactive tool to let a user to modify the location of control
% points. This is useful in case the image is very dim and some parts of
% the patterns are almost invisible or broken.
%
% bb is the projection (max intensity or mean image) of a stack so that the
% user can see the worm.
%
% by Hanchuan Peng
% 20080805

% bb=max(squeeze(inimg(:,:,:,1)),[],3);
bposxx = [bpos(:).y]; %note the bpos coordinates are permuted
bposyy = [bpos(:).x]; %note the bpos coordinates are permuted
for i=1:length(bposxx),
    bposmark{i} = 'ro';
end;

while 1, 
    hold off;
    imshow(bb); axis image; colormap(gray)
    hold on
    for j=1:length(bposxx),
        plot(bposxx(j), bposyy(j), bposmark{j});
    end;

    [cur_xx,cur_yy, bt]=ginput(1); 
    if bt=='q', break; end; 
    
    [b_found, min_dis, min_ind] = find_closest_bpos(bposxx, bposyy, cur_xx, cur_yy);
    if b_found,
        fprintf('Seem you have selected an existing control point. \n');
        fprintf('What you want to do next? Type a number to specify an option. \n');
        fprintf('1: Move it to the location you just clicked. \n');
        fprintf('2: Delete the selected point. \n');
        fprintf('3: Add a new control point at the location you clicked (note: this may cause wrong result!). \n');
        fprintf('4: done. \n');
        fprintf('999: clear all control points. \n');

        fprintf('all others: Oops, - a wrong click. Do nothing. \n');
try
        R = input('Choice: ');
        
        switch (R),
            case 1,
                bposxx(min_ind) = cur_xx;
                bposyy(min_ind) = cur_yy;
                bposmark{min_ind} = 'g*';
            case 2,
                bposxx(min_ind) = [];
                bposyy(min_ind) = [];
                bposmark(min_ind) = [];
            case 3,
                bposxx = [bposxx, cur_xx];
                bposyy = [bposyy, cur_yy];
                bposmark{end+1} = 'g<';
            case 4,
	      fprintf('completed work');
              break;
            case 999,
                bposxx = [];
                bposyy = [];
                bposmark = {};
                bposxx = [cur_xx];
                bposyy = [cur_yy];
                bposmark = {'g*'};
            otherwise,
                fprintf('You chose to do nothing.\n');
        end; 
catch exception
                fprintf('You chose to do nothing.\n');
end;
    else,
        bposxx = [bposxx, cur_xx];
        bposyy = [bposyy, cur_yy];
        bposmark{end+1} = 'g<';
    end;
end;

fprintf('moving on\n');
% generate the new bpos array
for i=1:length(bposxx),
    bposnew(i).x = bposyy(i);
    bposnew(i).y = bposxx(i);
end;

% need to add a sorting function for the new bpos array
myord = corelinegraph(posdistmatrix(bposnew));
bposnew1 = bposnew(myord);
hold off;
imshow(bb); axis image; colormap(gray)
hold on
for j=1:length(bposnew1),
    plot(bposnew1(j).y, bposnew1(j).x, 'ro');
    h = text(bposnew1(j).y+5, bposnew1(j).x+5, num2str(j));
    set(h, 'color', [0 1 0]);
end;
bposnew = bposnew1;

return;

%%%

function [b_found, min_dis, min_ind] = find_closest_bpos(bposxx, bposyy, curxx, curyy)
[min_dis, min_ind] = min(sqrt((bposxx-curxx).^2 + (bposyy-curyy).^2));
if min_dis<8, %if within a 5-pixel radius
    b_found=1;
else,
    b_found=0;
end;
return;

