function correctImg = unifybgn(inimg)
% function correctImg = unifybgn(inimg)

% rectify non-uniform background
%
% Copyright F. Long
% 20060224

se = strel('disk',25);

sz = size(inimg);

correctImg = inimg;
correctImg(:) = 0;
'rectify non-uniform background'
for i=1:sz(3)
    i;
    correctImg(:,:,i) = imtophat(inimg(:,:,i),se);
end;

