function c12 = elegan_findWormBoundary20(a, id_gfp, id_dapi,conn)
%function c12 = elegan_findWormBoundary2(a, id_gfp, id_dapi)
%
% find worm boundary
%
% Copyright Fuhui Long & Hanchuan Peng
% 20051103, 20051129

%2010 sarah- assume only dapi channle was sent

id_gfp
id_dapi
% project to XY plane
projDirection = 3;

wormImg = uint8(a);
%proj1 = projWormTo2D(wormImg, projDirection); %this is old way
%proj1 = projWormTo2DMax(wormImg, projDirection); %this is new
%proj1 = proj1/max(proj1(:))*255;
'permuting'
img2 = permute(a, [3 1 2]);
clear a
%close all;



%a1 = proj1(:,:,id_gfp);
%b1 = medfilt2(uint8(a1));
%dip_image(b1)

'PROJECTING'
a2 = squeeze(max(img2(:,:,:)));
clear img2
dipshow(a2)
gmax = medfilt2(uint8(a2));
clear a2
dip_image(gmax)



gDiv1 = graythresh(gmax)*255;
dipshow(255*uint8(gmax>gDiv1));

c =1;
jump = 5
d = bwlabeln(gmax>c,conn);
size(unique(d(find(gmax>gDiv1))),1)

connect = [1:26]*0

%while((size(unique(d(find(gmax>gDiv1))),1) == 1) && ( c < 15))
while(1)
    close all
    dipshow(4*uint8(gmax>c)+uint8(gmax>gDiv1)*1,'labels')
    diptruesize(25)
    diptruesize('off')
    pause(2)
    %%try to do an optimized search
    connect(c)= size(unique(d(find(gmax>gDiv1))),1)
    %search backward if it's big
    if (connect(c) > 1 )
        'search backwards for a 1'
        if(c == 1)
            break;
        elseif(c > 1 && connect(c-1) == 1)
            break;
        end;
         
        %go halfway to the next point
        nextVal = find(connect(1:c-1)==1)

        if size(nextVal,2) == 0
            nextVal(1) = 1
        end;
        c = round((nextVal(end)+c)/2)
        
    %search forward        

    else
        'search forward for a non-zero/one'
        if (c==size(connect,2))
            break;
        elseif (c < size(connect,2) && connect(c+1) > 1)
            break;
        end;    

        %go halfway to the next point
        nextVal = c+find(connect(c+1:end)>1)

        if size(nextVal,2) == 0
            nextVal(1) = size(connect,2)
        end;
        c = round((nextVal(1)+c)/2)
        
    end;
    d = bwlabeln(gmax>c,conn);
    size(unique(d(find(gmax>gDiv1))),1)
end;
close all
dipshow(255*uint8(gmax>c));

thre = c-1
c12 = (gmax>thre);
clear gmax
try
    c12 = medfilt2(c12);
catch
    'medfilter was hte problem'
end;
c12label = bwlabel(c12);

clear c12
dipshow(uint8(c12label))

% remove small regions and regions that touch the worm body
for i=1:max(c12label(:))
    objSize(i) = nnz(c12label==i);
end;

[maxObj, maxidx] = max(objSize);
maxidx
maxObj
c12label = (c12label==maxidx);

se = strel('disk',5,0);
c12eroded = imerode(c12label,se);
clear c12label
dipshow(uint8(c12eroded>0)*255)

c12 = c12eroded;
clear c12eroded;

