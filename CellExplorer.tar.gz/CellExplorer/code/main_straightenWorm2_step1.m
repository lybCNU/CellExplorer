function main_straightenWorm2_step1(inimg, id_gfp, id_dapi, zoom_f,prefix)

%20100902 sarah, assume only dapi was sent

inputarg = inimg;
if isa(inputarg, 'char'),
 inimg = uint8(readim(inputarg));
else,
 inimg = uint8(inputarg);
end;

nd = ndims(inimg);
if (nd<3 | nd>5),
  error('You have to specify a stack with 3 or 4 dimensions.');
return;
end;

c12 = elegan_findWormBoundary20(inimg, id_gfp, id_dapi,8);

try
[bpos] = elegantail_backbone_2d(uint8(double(c12)+0));
catch exception
'special case that cannot have it at 20'
c12 = elegan_findWormBoundary20_2(inimg, id_gfp, id_dapi,8);

  [bpos] = elegantail_backbone_2d(uint8(double(c12)+0));
end

clear inimg
clear c12
for i=1:length(bpos), c(round(bpos(i).x), round(bpos(i).y))=1; bposSave.x(i) = bpos(i).x; bposSave.y(i) = bpos(i).y; end;
save([prefix,'dim.mat'],'-struct','bposSave');
