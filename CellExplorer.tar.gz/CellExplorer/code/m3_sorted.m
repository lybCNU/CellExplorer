function pointer = sorted(meshsites, sites)
%SORTED Locate sites with respect to meshsites.
%
%   Given sequences MESHSITES and SITES, returns the index sequence
%   POINTER  (a  r o w  vector)  for which
%
%   POINTER(j) = #{ i : MESHSITES(i)  <=  sort(SITES)(j) },  all  j .
%
%   Thus, if both MESHSITES and SITES are nondecreasing, then
%
%   MESHSITES(POINTER(j))  <= SITES(j) < MESHSITES(POINTER(j)+1) ,
%
%   with the obvious interpretations when  POINTER(j) = 0  or
%   POINTER(j)+1 = length(MESHSITES) + 1 .
%
%   For example, 
%
%       sorted( [1 2 3 4], [0 1 2.1 2.99 3.5 4 5])
%
%   specifies 1:4 as MESHSITES and [0 1 2.1 2.99 3.5 4 5] as SITES and
%   gives the output  [0 1 2 2 3 4 4] .
%
%   See also PPUAL, SPVAL.

%   C. de Boor latest change: May 27, 1989
%   cb : 20 oc 94 : correct help
%   cb :  9 may '95 (use .' instead of ')
%   cb : 19 nov 95 (correct help; bring back to original, simple form since
%                   SORT doesn't reorder like terms any more)
%   cb : 28aug99 (point --> site, update help)
%   Copyright 1987-2000 C. de Boor and The MathWorks, Inc.
%   $Revision: 1.10 $

[ignored,index] = sort([meshsites(:).' sites(:).']);
pointer = find(index>length(meshsites))-[1:length(sites)];
