%MINUS   Overloaded operator for a-b.

% (C) Copyright 1999-2000               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, April 2000.

function out = minus(in1,in2)
try
   [in1,in2,arrayop] = doarrayinputs(in1,in2);
   if arrayop
      out = compute2array('minus',in1,in2);
   else
      out = compute2('minus',in1,in2);
   end
catch
   error(di_firsterr)
end
