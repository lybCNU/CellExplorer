%TRACE   Sum of the diagonal elements
%    TRACE(A) is the sum of the diagonal elements of the tensor image

% (C) Copyright 1999-2007               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Bernd Rieger, November 2000.

function out = trace(a)
if ~istensor(a)
   error('input should be a tensor image.')
end
if imarsize(a,1)~=imarsize(a,2)
   error('tensor image should be square.');
end
out = dip_image('zeros',size(a(1,1)));
for ii=1:size(a,1)
   out = out+a(ii,ii);
end
