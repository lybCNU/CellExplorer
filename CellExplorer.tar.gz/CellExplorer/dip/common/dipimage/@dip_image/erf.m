%ERF   Error function.
%  ERF(B) is the error function for each of the pixels of B.

% (C) Copyright 1999-2000               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, October 2000.

function out = erf(in)
try
   out = compute1('erf',in);
catch
   error(di_firsterr)
end
