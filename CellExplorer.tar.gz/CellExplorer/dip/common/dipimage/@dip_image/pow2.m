%POW2   Base 2 power.
%   POW2(B) is 2 raised to the power of B, on a per-pixel basis.

% (C) Copyright 1999-2008               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, May 2000.
% 10 March 2008: Fixed bug. COMPUTE1 has a new PHYSDIMS input parameter.

function out = pow2(in)
try
   [in,dims,out_type,out_phys] = do1input(in);
   out = compute1('pow2',in,dims,'dfloat',out_phys);
catch
   error(di_firsterr)
end
