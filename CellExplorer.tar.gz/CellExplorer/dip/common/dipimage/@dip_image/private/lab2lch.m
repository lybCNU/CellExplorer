%LAB2LCH   Convert color image from L*a*b* to L*C*H*.

% (C) Copyright 1999-2008               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, August 2008.

function out = lab2lch(in)
a = in(2); % a = C * cos(H);
b = in(3); % b = C * sin(H);
C = sqrt(a^2+b^2);
H = atan2(b,a);
out = di_joinchannels(in(1).color,'L*C*H*',in(1),C,H);
