%LCH2LAB   Convert color image from L*C*H* to L*a*b*.

% (C) Copyright 1999-2008               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, August 2008.

function out = lch2lab(in)
C = in(2);
H = in(3);
a = C*cos(H);
b = C*sin(H);
out = di_joinchannels(in(1).color,'L*a*b*',in(1),a,b);
