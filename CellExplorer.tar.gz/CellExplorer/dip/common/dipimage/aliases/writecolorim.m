%WRITECOLORIM   Alias for WRITEIM

function out = writecolorim(varargin)
out = writeim(varargin{:});
