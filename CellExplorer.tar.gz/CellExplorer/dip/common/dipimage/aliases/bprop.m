%BPROP   Alias for BPROPAGATION.

function out = bprop(varargin)
out = bpropagation(varargin{:});
