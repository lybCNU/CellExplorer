%THRESH_ISODATA   Alias for THRESHOLD('isodata').

function out = thresh_isodata(in)
out = threshold(in,'isodata');
