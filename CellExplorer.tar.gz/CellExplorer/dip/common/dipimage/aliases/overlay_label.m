%OVERLAY_LABEL alias for OVERLAY

function out = overlay_label(varargin)
out = overlay(varargin{:});
