%BCLOS   Alias for BCLOSING.

function out = bclos(varargin)
out = bclosing(varargin{:});
