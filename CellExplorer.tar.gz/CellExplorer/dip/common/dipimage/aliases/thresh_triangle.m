%THRESH_TRIANGLE   Alias for THRESHOLD('triangle').

function out = thresh_triangle(in)
out = threshold(in,'triangle');
