%BLURUNIF   Alias for UNIF.

function out = blurunif(varargin)
out = unif(varargin{:});
